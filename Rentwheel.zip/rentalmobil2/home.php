<figure class="thumbnail move_img wow slideInLeft" data-wow-delay="0.5s"></figure>
<div class="container">
	<div class="row">
		<div class="col-sm-12 col-lg-6 col-lg-push-6">
		<?php 
		   if(!isset($_SESSION['kd_cs'])){
		?>
			<h2>Selamat Datang di Rentwheel</h2>
			<p>Menyewa mobil kini semakin mudah dengan adanya layanan dari Rentwheel yang handal</p>
		<?php }else{ ?>
		<h1>Selamat Datang</h1>
			<p><?php echo $_SESSION['nama_cs'] ?></p>
		<?php } ?>
		</div>
	</div>
</div>
