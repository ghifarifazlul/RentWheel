<?php
include '../koneksi.php';

	$hapusdata=$koneksi->query("DELETE FROM tbcostumer where kd_cs='$_GET[id]'");

	if ($hapusdata){
		echo "<script>
			alert ('Data Customer BERHASIL dihapus !');
			window.location.href='../index.php?page=costumer';</script>";

	}else{
		echo"<script>alert('Data Customer GAGAL dihapus !');
		window.location.href='../index.php?page=costumer';</script>";
	} 

?>