<figure class="thumbnail move_img wow slideInLeft" data-wow-delay="0.5s"></figure>
<div class="container">
	<div class="row">
		<div class="col-sm-12 col-lg-6 col-lg-push-6">
			<h3>Selamat Datang <?php echo $_SESSION ['nama_cs'] ?></h3>
			<p>Silahkan pilih menu yang anda butuhkan</p>
		</div>
	</div>
</div>
